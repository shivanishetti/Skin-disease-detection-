
import React, { useRef } from 'react';
import type { SelectedImage } from '../types';
import { Icon } from './Icon';

interface ImageUploadButtonProps {
  onImageSelect: (image: SelectedImage) => void;
  disabled: boolean;
}

const fileToData = (file: File): Promise<SelectedImage> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      if (base64String) {
        resolve({
          file: file,
          previewUrl: URL.createObjectURL(file),
          base64: base64String,
          mimeType: file.type,
        });
      } else {
        reject(new Error("Failed to read file"));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const ImageUploadButton: React.FC<ImageUploadButtonProps> = ({ onImageSelect, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const imageData = await fileToData(file);
        onImageSelect(imageData);
      } catch (error) {
        console.error("Error processing file:", error);
        // You might want to show an error to the user here
      }
    }
    // Reset file input value to allow selecting the same file again
    if(fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  return (
    <>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
        disabled={disabled}
      />
      <button
        type="button"
        onClick={() => fileInputRef.current?.click()}
        disabled={disabled}
        className="p-2 text-gray-400 hover:text-gray-200 disabled:opacity-50"
      >
        <Icon type="paperclip" className="w-6 h-6" />
      </button>
    </>
  );
};
