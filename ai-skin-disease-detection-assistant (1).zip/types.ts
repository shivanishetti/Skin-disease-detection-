
export type Sender = 'user' | 'ai';

export interface Message {
  id: string;
  sender: Sender;
  text: string;
  imageUrl?: string;
}

export interface ImagePart {
  inlineData: {
    data: string;
    mimeType: string;
  };
}

export interface SelectedImage {
  file: File;
  previewUrl: string;
  base64: string;
  mimeType: string;
}
