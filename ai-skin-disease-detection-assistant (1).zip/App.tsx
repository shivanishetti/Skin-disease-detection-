
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Message, SelectedImage, ImagePart } from './types';
import { getAiResponse } from './services/geminiService';
import { ChatBubble } from './components/ChatBubble';
import { Icon } from './components/Icon';
import { Spinner } from './components/Spinner';
import { ImageUploadButton } from './components/ImageUploadButton';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedImage, setSelectedImage] = useState<SelectedImage | null>(null);

  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([
      {
        id: 'init',
        sender: 'ai',
        text: 'Hello! I am an AI assistant designed to help identify possible skin conditions. \n\nPlease describe your skin issue or upload a clear photo of the affected area. \n\n**Disclaimer:** I am not a medical professional. Please consult a dermatologist for a proper diagnosis.',
      },
    ]);
  }, []);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleImageSelect = (image: SelectedImage) => {
    setSelectedImage(image);
  };

  const removeSelectedImage = () => {
    if (selectedImage) {
      URL.revokeObjectURL(selectedImage.previewUrl);
      setSelectedImage(null);
    }
  };
  
  const handleSendMessage = useCallback(async () => {
    if ((!userInput.trim() && !selectedImage) || isLoading) return;

    const userMessageText = userInput.trim() || 'Here is the image of my skin condition.';

    const userMessage: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: userMessageText,
      imageUrl: selectedImage?.previewUrl,
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setUserInput('');

    let imagePart: ImagePart | null = null;
    if (selectedImage) {
      imagePart = {
        inlineData: {
          data: selectedImage.base64,
          mimeType: selectedImage.mimeType,
        },
      };
      // We don't revoke the object URL here because it's used by the message
      setSelectedImage(null);
    }

    try {
      const aiResponseText = await getAiResponse(userMessageText, imagePart);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiResponseText,
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error('Failed to get AI response:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: 'Sorry, I encountered an error. Please try again later.',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [userInput, selectedImage, isLoading]);

  return (
    <div className="flex flex-col h-screen bg-gray-900 max-w-4xl mx-auto">
      <header className="p-4 border-b border-gray-700 text-center">
        <h1 className="text-xl font-bold text-gray-100">AI Skin Disease Detection Assistant</h1>
      </header>

      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="space-y-4">
          {messages.map((msg) => (
            <ChatBubble key={msg.id} message={msg} />
          ))}
          {isLoading && (
            <div className="flex justify-start mb-4">
              <div className="max-w-xs md:max-w-md lg:max-w-2xl rounded-lg px-4 py-3 bg-gray-700 text-gray-200 rounded-bl-none flex items-center space-x-2">
                <Spinner />
                <span>Thinking...</span>
              </div>
            </div>
          )}
          <div ref={endOfMessagesRef} />
        </div>
      </main>

      <footer className="p-4 border-t border-gray-700">
        <div className="bg-gray-800 rounded-lg p-2 flex items-center">
          <ImageUploadButton onImageSelect={handleImageSelect} disabled={isLoading || !!selectedImage} />
          <div className="flex-1 relative">
            {selectedImage && (
              <div className="absolute bottom-full left-0 mb-2 p-1 bg-gray-700 rounded-lg shadow-lg">
                <img src={selectedImage.previewUrl} alt="Selected" className="h-20 w-20 object-cover rounded" />
                <button
                  onClick={removeSelectedImage}
                  className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-0.5"
                  aria-label="Remove image"
                >
                  <Icon type="close" className="w-4 h-4" />
                </button>
              </div>
            )}
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Describe your skin condition..."
              className="w-full bg-transparent text-gray-200 placeholder-gray-500 focus:outline-none px-2"
              disabled={isLoading}
            />
          </div>
          <button
            onClick={handleSendMessage}
            disabled={isLoading || (!userInput.trim() && !selectedImage)}
            className="p-2 text-blue-500 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed"
          >
            {isLoading ? <Spinner /> : <Icon type="send" className="w-6 h-6" />}
          </button>
        </div>
      </footer>
    </div>
  );
};

export default App;
