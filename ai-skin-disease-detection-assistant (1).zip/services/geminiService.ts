
import { GoogleGenAI, Chat, Part } from "@google/genai";
import { SYSTEM_PROMPT } from '../constants';
import type { ImagePart } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real application, you'd want to handle this more gracefully.
  // For this context, throwing an error is sufficient.
  console.error("API_KEY is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

// Using a module-level variable to hold the chat session.
let chatSession: Chat | null = null;

const getChatSession = (): Chat => {
  if (!chatSession) {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_PROMPT,
      }
    });
  }
  return chatSession;
};

export const getAiResponse = async (prompt: string, image: ImagePart | null): Promise<string> => {
  const chat = getChatSession();
  
  try {
    const parts: Part[] = [];
    if (image) {
        parts.push(image);
    }
    parts.push({ text: prompt });

    const result = await chat.sendMessage({ parts });
    return result.text;
  } catch (error) {
    console.error("Error getting AI response:", error);
    // In case of an error, reset the chat session
    chatSession = null; 
    return "I'm sorry, but I encountered an error. It's best to consult a healthcare professional for any medical concerns. Please refresh the page and try again if you'd like.";
  }
};
